
Configuration ContosoWebsiteD
{
	param ($MachineName)
	
	Node $MachineName
	{
		#Install the IIS Role
		WindowsFeature IIS
		{
			Ensure = "Present"
			Name = "Web-Server"
		}
		
		#Install ASP.NET 4.5
		WindowsFeature ASP
		{
			Ensure = "Present"
			Name = "Web-Asp-Net45"
		}
		
		WindowsFeature WebMgmtTools
		{
			Ensure = "Present"
			Name   = "Web-Mgmt-Tools"
		}
		
		File Racks
		{
			Ensure          = "Present"
			DestinationPath = "C:\inetpub\Racks"
		   	Type            = "Directory"
		}
		File DirectoryCopy
		{
			Ensure = "Present" # Present, Absent.
			Type = "Directory" # File, Directory
			Recurse = $true # $true, $false
			SourcePath = "C:\Program Files\WindowsPowerShell\Modules\Racks"
			DestinationPath = "C:\inetpub\Racks"
		}
		
		
		WindowsFeature WebServerManagementConsole
		{
			Name = "Web-Mgmt-Console"
			Ensure = "Present"
		}
	}
}


ContosoWebsiteD

#Stop-WebSite -Name "Default Web Site"
#New-Item iis:\Sites\racks -bindings @{ protocol = "http"; bindingInformation = ":80:*" } -physicalPath "C:\inetpub\racks\racks"
