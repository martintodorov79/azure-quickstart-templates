﻿
#Functions
function Stop-DefaultWebSite
{
	Stop-WebSite -Name "Default Web Site"
}
Stop-DefaultWebSite
function New-Web-Site
{
	New-Item iis:\Sites\racks -bindings @{ protocol = "http"; bindingInformation = ":80:*" } -physicalPath "C:\inetpub\racks\racks"
}


# Move files

			$SourcePath = "C:\Program Files\WindowsPowerShell\Modules\Racks"
			$DestinationPath = "C:\inetpub\Racks"
robocopy $SourcePath $DestinationPath '*.*' /E 


New-Web-Site